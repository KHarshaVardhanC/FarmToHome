package com.ftohbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FtohbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FtohbackendApplication.class, args);
	}

}
