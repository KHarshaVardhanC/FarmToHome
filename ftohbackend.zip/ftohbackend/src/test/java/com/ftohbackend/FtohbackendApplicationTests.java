package com.ftohbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FtohbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
