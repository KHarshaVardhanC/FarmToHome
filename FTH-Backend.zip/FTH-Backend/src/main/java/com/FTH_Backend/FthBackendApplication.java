package com.FTH_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FthBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FthBackendApplication.class, args);
	}

}
