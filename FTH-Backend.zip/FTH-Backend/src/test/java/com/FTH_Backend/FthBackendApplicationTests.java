package com.FTH_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FthBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
